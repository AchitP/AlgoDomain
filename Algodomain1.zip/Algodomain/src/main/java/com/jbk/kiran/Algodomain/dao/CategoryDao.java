package com.jbk.kiran.Algodomain.dao;

import java.util.List;

import com.jbk.kiran.Algodomain.entity.Category;

public interface CategoryDao {
	
	String addCategory(Category category);
	List<Category> getAllCategory();
	Category getById(String id);
	Category updateCategory(Category category);
	String deleteCategory(String catagory);

}
