
package com.jbk.kiran.Algodomain.entity;

import java.util.Objects;

public class ProductDetails {
	
	private int productId;
	private String productName;
	private String productType;
	private String productcatagory;
	private double basePrice;
	private double descount;
	private Charges charges;
	private double finalprice;
	@Override
	public int hashCode() {
		return Objects.hash(basePrice, charges, descount, finalprice, productId, productName, productType,
				productcatagory);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductDetails other = (ProductDetails) obj;
		return Double.doubleToLongBits(basePrice) == Double.doubleToLongBits(other.basePrice)
				&& Objects.equals(charges, other.charges)
				&& Double.doubleToLongBits(descount) == Double.doubleToLongBits(other.descount)
				&& Double.doubleToLongBits(finalprice) == Double.doubleToLongBits(other.finalprice)
				&& productId == other.productId && Objects.equals(productName, other.productName)
				&& Objects.equals(productType, other.productType)
				&& Objects.equals(productcatagory, other.productcatagory);
	}
	@Override
	public String toString() {
		return "ProductDetails [productId=" + productId + ", productName=" + productName + ", productType="
				+ productType + ", productcatagory=" + productcatagory + ", basePrice=" + basePrice + ", descount="
				+ descount + ", charges=" + charges + ", finalprice=" + finalprice + "]";
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getProductcatagory() {
		return productcatagory;
	}
	public void setProductcatagory(String productcatagory) {
		this.productcatagory = productcatagory;
	}
	public double getBasePrice() {
		return basePrice;
	}
	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}
	public double getDescount() {
		return descount;
	}
	public void setDescount(double descount) {
		this.descount = descount;
	}
	public Charges getCharges() {
		return charges;
	}
	public void setCharges(Charges charges) {
		this.charges = charges;
	}
	public double getFinalprice() {
		return finalprice;
	}
	public void setFinalprice(double finalprice) {
		this.finalprice = finalprice;
	}
	public ProductDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductDetails(int productId, String productName, String productType, String productcatagory,
			double basePrice, double descount, Charges charges, double finalprice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productType = productType;
		this.productcatagory = productcatagory;
		this.basePrice = basePrice;
		this.descount = descount;
		this.charges = charges;
		this.finalprice = finalprice;
	}
	

}
