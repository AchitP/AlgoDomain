package com.jbk.kiran.Algodomain.service;

import java.util.List;

import com.jbk.kiran.Algodomain.entity.Product;
import com.jbk.kiran.Algodomain.entity.ProductDetails;

public interface ProductService {
	
	List<Product> getallProduct();
	ProductDetails getProductById(int id);
	Product addProduct(Product product);
	Product updateProduct(Product product);
	String deleteProduct(int id);

}
