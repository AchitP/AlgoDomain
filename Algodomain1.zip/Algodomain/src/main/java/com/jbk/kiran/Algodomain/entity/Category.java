package com.jbk.kiran.Algodomain.entity;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Category {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cid;
	private String productCatagory;
	private int discount;
	private int gst;
	private double deliveryCharge;
	public Category() {
		super();
	}
	public Category(int cid, String productCatagory, int discount, int gST, double deliveryCharge) {
		super();
		this.cid = cid;
		this.productCatagory = productCatagory;
		this.discount = discount;
		this.gst = gST;
		this.deliveryCharge = deliveryCharge;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getProductCatagory() {
		return productCatagory;
	}
	public void setProductCatagory(String productCatagory) {
		this.productCatagory = productCatagory;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public int getGST() {
		return gst;
	}
	public void setGST(int gST) {
		this.gst = gST;
	}
	public double getDeliveryCharge() {
		return deliveryCharge;
	}
	public void setDeliveryCharge(double deliveryCharge) {
		this.deliveryCharge = deliveryCharge;
	}
	@Override
	public String toString() {
		return "Category [cid=" + cid + ", ProductCatagory=" + productCatagory + ", discount=" + discount + ", GST="
				+ gst + ", deliveryCharge=" + deliveryCharge + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(gst, productCatagory, cid, deliveryCharge, discount);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Category other = (Category) obj;
		return gst == other.gst && Objects.equals(productCatagory, other.productCatagory) && cid == other.cid
				&& Double.doubleToLongBits(deliveryCharge) == Double.doubleToLongBits(other.deliveryCharge)
				&& discount == other.discount;
	}
		
}
