package com.jbk.kiran.Algodomain.service;

import java.util.List;

import com.jbk.kiran.Algodomain.entity.Category;

public interface CategoryService {

	String addCategory(Category category);
	List<Category> getAllCategory();
	Category getById(String id);
	Category updateCategory(Category category);
	String deleteCategory(String catagory);

}
