package com.jbk.kiran.Algodomain.entity;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productId;
	private String productName;
	private String productType;
	private String productcatagory;
	private double productPrice;
	
	@OneToOne(fetch = FetchType.EAGER)
	private Category category;
	public Product() {
		super();
	}
	public Product(int productId, String productName, String productType, String productcatagory, double productPrice,
			Category category) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productType = productType;
		this.productcatagory = productcatagory;
		this.productPrice = productPrice;
		this.category = category;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getProductcatagory() {
		return productcatagory;
	}
	public void setProductcatagory(String productcatagory) {
		this.productcatagory = productcatagory;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productType=" + productType
				+ ", productcatagory=" + productcatagory + ", productPrice=" + productPrice + ", category=" + category
				+ "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(category, productId, productName, productPrice, productType, productcatagory);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		return Objects.equals(category, other.category) && productId == other.productId
				&& Objects.equals(productName, other.productName)
				&& Double.doubleToLongBits(productPrice) == Double.doubleToLongBits(other.productPrice)
				&& Objects.equals(productType, other.productType)
				&& Objects.equals(productcatagory, other.productcatagory);
	}
	
}
