package com.jbk.kiran.Algodomain.entity;

import java.util.Objects;

public class Charges {
	
	private double gst;
	private double deilivery;
	public Charges() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Charges(double gst, double deilivery) {
		super();
		this.gst = gst;
		this.deilivery = deilivery;
	}
	public double getGst() {
		return gst;
	}
	public void setGst(double gst) {
		this.gst = gst;
	}
	public double getDeilivery() {
		return deilivery;
	}
	public void setDeilivery(double deilivery) {
		this.deilivery = deilivery;
	}
	@Override
	public String toString() {
		return "Charges [gst=" + gst + ", deilivery=" + deilivery + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(deilivery, gst);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Charges other = (Charges) obj;
		return Double.doubleToLongBits(deilivery) == Double.doubleToLongBits(other.deilivery)
				&& Double.doubleToLongBits(gst) == Double.doubleToLongBits(other.gst);
	}
	
	

}
