package com.jbk.kiran.Algodomain.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jbk.kiran.Algodomain.dao.CategoryDao;
import com.jbk.kiran.Algodomain.dao.ProductDao;
import com.jbk.kiran.Algodomain.entity.Category;
import com.jbk.kiran.Algodomain.entity.Charges;
import com.jbk.kiran.Algodomain.entity.Product;
import com.jbk.kiran.Algodomain.entity.ProductDetails;

@Service
public class ProductService_impl implements ProductService{
	
	@Autowired
	ProductDao dao;
	
	@Autowired
	CategoryDao cdao;

	@Override
	public List<Product> getallProduct() {
		return dao.getallProduct();
	}

	@Override
	public ProductDetails getProductById(int id) {
		Product product = dao.getProductById(id);
		Category ct = product.getCategory();
		
		ProductDetails pdls=new ProductDetails();
		
		pdls.setProductId(product.getProductId());
		pdls.setProductName(product.getProductName());
		pdls.setProductcatagory(product.getProductcatagory());
		pdls.setBasePrice(product.getProductPrice());
		pdls.setProductType(product.getProductType());
		
		double price = product.getProductPrice();
		int dsc = ct.getDiscount();
		pdls.setDescount(getDiscount(price, dsc));
		
		int gst = ct.getGST();
		
		Charges ch=new Charges();
		
		ch.setGst(getGST((price-pdls.getDescount()), gst));
		ch.setDeilivery(ct.getDeliveryCharge());
		
		pdls.setCharges(ch);
		
		pdls.setFinalprice( (price-pdls.getDescount())+ch.getGst()+ct.getDeliveryCharge() );
		
		return pdls;
	}

	@Override
	public Product addProduct(Product product) {
		Category ct=new Category();
		List<Category> list=cdao.getAllCategory();
		for(Category c: list) {
			if(product.getProductcatagory().equals(c.getProductCatagory())) {
				ct=c;
				break;
			}
		}
		product.setCategory(ct);
		return dao.addProduct(product);
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteProduct(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	
    public static double getDiscount(double basePrice, int discount) {
    	double discountPrice=(basePrice*discount)/100;
    	return discountPrice;
    }
    public static double getGST(double basePrice, int gst) {
		return (basePrice*gst)/100;
	}

}
