package com.jbk.kiran.Algodomain.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jbk.kiran.Algodomain.dao.CategoryDao;
import com.jbk.kiran.Algodomain.entity.Category;
@Service
public class CategoryService_impl implements CategoryService {
	@Autowired
	CategoryDao dao;
	

	@Override
	public String addCategory(Category category) {
		
		String str = dao.addCategory(category);
	
		return str;
	}

	@Override
	public List<Category> getAllCategory() {
		
		
		return dao.getAllCategory();
	}

	@Override
	public Category getById(String id) {
	
		return dao.getById(id);
	}

	@Override
	public Category updateCategory(Category category) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteCategory(String catagory) {
		// TODO Auto-generated method stub
		return null;
	}

}
