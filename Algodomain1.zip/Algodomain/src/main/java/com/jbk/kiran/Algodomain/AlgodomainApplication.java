package com.jbk.kiran.Algodomain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlgodomainApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlgodomainApplication.class, args);
	}

}
