package com.jbk.kiran.Algodomain.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jbk.kiran.Algodomain.entity.Category;
import com.jbk.kiran.Algodomain.entity.Product;
import com.jbk.kiran.Algodomain.entity.ProductDetails;
import com.jbk.kiran.Algodomain.service.CategoryService;
import com.jbk.kiran.Algodomain.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService pservice;
	
	@Autowired
	CategoryService cservice;
	
	
	@PostMapping("/putdata")
	public Product addProduct(@RequestBody Product product) {
		return pservice.addProduct(product);
	}
	@PostMapping("/setdata")
	public String categoryString(@RequestBody Category category) {
		return cservice.addCategory(category);
		
	}
	
	@GetMapping("/getData/{id}")
	public ProductDetails getById(@PathVariable int id) {
		return pservice.getProductById(id) ;
	}

}
