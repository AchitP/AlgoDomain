package com.jbk.kiran.Algodomain.dao;

import java.util.List;

import com.jbk.kiran.Algodomain.entity.Product;

public interface ProductDao {
	
	List<Product> getallProduct();
	Product getProductById(int id);
	Product addProduct(Product product);
	Product updateProduct(Product product);
	String deleteProduct(int id);

}
