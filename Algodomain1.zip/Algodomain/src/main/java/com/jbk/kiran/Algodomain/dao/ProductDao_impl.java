package com.jbk.kiran.Algodomain.dao;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jbk.kiran.Algodomain.entity.Product;

@Repository
public class ProductDao_impl implements ProductDao {
	
	@Autowired
	SessionFactory sf;

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getallProduct() {
		Session session = sf.openSession();
		List<Product> plist = new  ArrayList<Product>();
		try {
			@SuppressWarnings("deprecation")
			Criteria cr = session.createCriteria(Product.class);
			plist = cr.list();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally {
			session.close();
		}
		return plist;
	}

	@Override
	public Product getProductById(int id) {
		Session session = sf.openSession();
		Product p=new Product();
		try {
			p=session.get(Product.class, id);
			
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			session.close();
		}
		return p;
	}

	@Override
	public Product addProduct(Product product) {
		Session session = sf.openSession();
		Transaction tt = session.beginTransaction();
		try {
			session.save(product);
			tt.commit();
			
		} catch (Exception e) {
		 e.printStackTrace();
		}finally {
			session.close();
		}
		return product;
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteProduct(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
