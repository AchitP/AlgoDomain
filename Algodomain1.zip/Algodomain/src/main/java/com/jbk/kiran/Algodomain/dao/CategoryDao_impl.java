package com.jbk.kiran.Algodomain.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.jbk.kiran.Algodomain.entity.Category;

@Repository
public class CategoryDao_impl implements CategoryDao{
	
	@Autowired
	SessionFactory sf;

	@Override
	public String addCategory(Category category) {
		String ss=new String();
		Session session = sf.openSession();
		try {
			Transaction tt = session.beginTransaction();
			session.save(category);
			tt.commit();
			ss="Category Added Successfully \n" +category.toString();
		} catch (Exception e) {
			e.printStackTrace();
			ss="something get wrong";
		}finally {
			session.close();
		}
		return ss;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Category> getAllCategory() {
		Session session = sf.openSession();
		List<Category> list=new ArrayList();
		try {
			@SuppressWarnings("deprecation")
			Criteria ctr = session.createCriteria(Category.class);
			list=ctr.list();
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			session.close();
		}
		return list;
	}

	@Override
	public Category getById(String id) {
		Session session =sf.openSession();
		Category city=new Category();
		try {
			city=session.get(Category.class, id);
			
		} catch (Exception e) {

		}finally {
			session.close();
		}
		return null;
	}

	@Override
	public Category updateCategory(Category category) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteCategory(String catagory) {
		// TODO Auto-generated method stub
		return null;
	}

}
